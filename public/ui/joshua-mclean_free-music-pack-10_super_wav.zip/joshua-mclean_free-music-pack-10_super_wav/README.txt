Free Music Pack 10: Super 2
By Joshua McLean

______________________
\ LICENSE INFO
 ---------------------

These tracks are released under a CREATIVE COMMONS ATTRIBUTION 4.0 INTERNATIONAL
license. See LICENSE.txt for the full text of the license.

You are permitted to utilize these tracks in commercial releases.

You MUST include the FOLLOWING CREDIT in YOUR MEDIA (game, video, etc.):

  Contains music ©2021 Joshua McLean (https://joshua-mclean.itch.io)
  Licensed under Creative Commons Attribution 4.0 International

Any unauthorized use (i.e. without the above credit) presents as copyright
infringement and is strictly illegal.

______________________
\ MORE MUSIC
 ---------------------

If you use the music, please support me!
Patrons on the Music Supporter tier get an exclusive iextra wth each free music pack.
Support on Patreon: https://www.patreon.com/JoshuaMcLean
Buy music on Bandcamp: https://joshuamclean.bandcamp.com/

Please mention @MrJoshuaMcLean with your project if you're on Twitter
https://twitter.com/MrJoshuaMcLean

For more FREE music, visit
https://joshua-mclean.itch.io/

To contact for commissions (original music)
Email / joshua.mclean@8bitstoinfinty.com
Twitter / @mrjoshuamclean
