import Phaser from 'phaser'

const sceneEvents = new Phaser.Events.EventEmitter()

export {
	sceneEvents
}
